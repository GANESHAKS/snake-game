﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using MySql.Data.MySqlClient;

namespace snake_game
{
    public partial class user : Form
    {
       public static string us = "noobie";
        public static int maxscore;
        public static string maxusr;
        main m;
        public user()
        {
            InitializeComponent();
            // load_datagrid();
           /* label1.Visible = false;
            label2.Visible = false;
            label3.Visible = false;*/
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != null)
            {
                us = textBox1.Text;
            }
            else
            {
                us = "noobie";
            }
            if (m == null)
            {
                m = new main();

                m.Show();
            }
            else
            {
                m.Show();
            }
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        /*public void  load_datagrid()
         {



             MySqlDataAdapter ad = database.load_datagrid();
             if (ad == null)
             {
            label5.Text = "cannot retrieve score ";
             }
             else
             {
                 label5.Text = "";
                 DataTable dt = new DataTable();
                 ad.Fill(dt);

                 dataGridView1.DataSource = dt;



             }


         }
           */
    }
}
