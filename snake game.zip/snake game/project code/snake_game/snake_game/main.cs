﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace snake_game
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }
        Form1 game;
        set s;
        about a;
        user u;
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (game == null)
            {
                game = new Form1();
               // MessageBox.Show("maduhkhfshjkd");
                game.Show();
            }
            else
            {
                game.Activate();
            }
          
         
            //this.Activate();
         
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (s == null)
            {
               s= new set();
                // MessageBox.Show("maduhkhfshjkd");
                s.Show();
            }
            else
            {
                s.Activate();
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (a == null)
            {
                a = new about();
                // MessageBox.Show("maduhkhfshjkd");
                a.Show();
            }
            else
            {
                a.Activate();
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (u == null)
            {
                u= new user();
           
                // MessageBox.Show("maduhkhfshjkd");
                u.Show();
               
            }
            else
            {
             //  u.load_datagrid()
                u.Activate();
               
            }
        }
    }
}
