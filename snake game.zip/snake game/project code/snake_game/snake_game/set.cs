﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace snake_game
{
 
    public partial class set : Form
    {
        main m;
        public static string c;
        public static Brush b=Brushes.Green;
       public static int sp=10;
        public set()
        {
            InitializeComponent();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // Brush color;
            if (comboBox1.Text != null)
            {
                c = comboBox1.Text;
                switch (c)
                {
                    /*Blue
                     Yello
                     Pink
                    Aqua
                    Orange*/
                    case "Aqua":
                      b= Brushes.Aqua;
                        break;
                    case "Blue":
                    b = Brushes.Blue;
                        break;
                    case "Brown":
                        b = Brushes.Brown;
                        break;
                    case "Orange":
                        b = Brushes.DarkOrange;
                        break;
                    case "Pink":
                        b = Brushes.Pink;
                        break;
                  
                }
            }

            if (m == null)
            {
                m = new main();

                m.Show();
            }
            else
            {
                m.Show();
            }
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            sp = 10;

        }

        private void button5_Click(object sender, EventArgs e)
        {
            sp = 20;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            sp = 30;
        }
    }
}
